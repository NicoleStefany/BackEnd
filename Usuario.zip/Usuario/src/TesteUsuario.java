import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TesteUsuario {

    private static final String SQL_CREATE_TABLE = "DROP TABLE IF EXISTS USUARIO; CREATE TABLE USUARIO"
            + "("
            + " ID INT PRIMARY KEY,"
            + " NOME VARCHAR (100) NOT NULL, "
            + " SOBRENOME VARCHAR (100) NOT NULL, "
            + " IDADE INT NOT NULL "
            + ")"
            ;

    private static final String SQL_INSERT_1 = "INSERT INTO USUARIO (ID, NOME, SOBRENOME, IDADE) VALUES (1, 'MARIA', 'SILVA', 50)";
    private static final String SQL_INSERT_2 = "INSERT INTO USUARIO (ID, NOME, SOBRENOME, IDADE) VALUES (2, 'JOSÉ', 'ALVES', 56)";
    private static final String SQL_INSERT_3 = "INSERT INTO USUARIO (ID, NOME, SOBRENOME, IDADE) VALUES (3, 'JOAQUIM', 'SILVA', 25)";

    private static final String SQL_DELETE = "DELETE FROM USUARIO WHERE ID = 3";

    private static final Logger LOGGER = Logger.getLogger(TesteUsuario.class);

    public static void main(String[] args) throws Exception{

        Connection connection = null;

        try {
            connection = getConnection();
            Statement statement = connection.createStatement();

            statement.execute(SQL_CREATE_TABLE);

            statement.execute(SQL_INSERT_1);
            statement.execute(SQL_INSERT_2);
            statement.execute(SQL_INSERT_3);

            statement.execute(SQL_DELETE);

            LOGGER.info("O usuário com o ID 3 foi excluido!");

        } catch (Exception e){
            e.printStackTrace();
        } finally {
            connection.close();
        }

    }

    private static Connection getConnection() throws Exception{
        Class.forName("org.h2.Driver").getDeclaredConstructor().newInstance();
        return DriverManager.getConnection("jdbc:h2:~/test","sa", "sa");
    }

}
